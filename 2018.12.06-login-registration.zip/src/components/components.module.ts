import { NgModule } from '@angular/core';
import { AppHeaderComponent } from './app-header/app-header';
@NgModule({
	declarations: [AppHeaderComponent],
	imports: [],
	exports: [AppHeaderComponent]
})
export class ComponentsModule {}
